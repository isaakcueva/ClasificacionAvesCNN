from django.contrib import admin
from .models import Ave # Importa tu modelo Ave

# Registra tu modelo Ave
admin.site.register(Ave)