import os
import numpy as np
from django.shortcuts import render
from django.conf import settings
from .models import Ave # ¡Importa tu modelo Ave!
from PIL import Image # Usaremos PIL para el preprocesamiento, es más flexible que load_img de Keras
import uuid # Para generar nombres de archivo únicos
from django.utils.text import slugify # Para limpiar nombres de archivo

# Importa la librería de tu modelo (TensorFlow/Keras)
from tensorflow.keras.models import load_model # O solo tensorflow si lo cargas directamente

# Cargar el modelo previamente entrenado globalmente
MODEL = None
try:
    
    model_path = os.path.join(settings.BASE_DIR, 'models', 'modelo_aves_rgb.h5')
    MODEL = load_model(model_path)
    print("Modelo cargado exitosamente.")
except Exception as e:
    print(f"Error al cargar el modelo: {e}")
    MODEL = None


BIRD_CLASSES_MODEL = [
    "Aguila_Pechinegra",
    "Carpinterito_Candela", 
    "Clarinero_Escarlata",
    "Condor_Andino",
    "Pava_Andina"
] 


# Tamaño de imagen 
IMG_HEIGHT = 256
IMG_WIDTH = 256


def home_view(request):
    """
    Vista para la página principal (HOME).
    """
    return render(request, 'classifier/index.html', {})


def classify_bird_view(request):
    """
    Vista para la página del clasificador.
    Maneja la subida de imágenes, clasificación y muestra de resultados.
    """
    uploaded_image_url = None
    predicted_ave_info = None 
    classification_error = None

    if request.method == 'POST' and 'bird_image' in request.FILES:
        uploaded_file = request.FILES['bird_image']

        # Generar un nombre de archivo único para guardar la imagen subida
        ext = uploaded_file.name.split('.')[-1]
        unique_filename = f"{uuid.uuid4().hex}.{ext}"
        uploaded_image_path = os.path.join(settings.MEDIA_ROOT, unique_filename)

        # Asegurarse de que el directorio MEDIA_ROOT exista
        if not os.path.exists(settings.MEDIA_ROOT):
            os.makedirs(settings.MEDIA_ROOT)

        # Guardar la imagen subida por el usuario
        with open(uploaded_image_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        uploaded_image_url = settings.MEDIA_URL + unique_filename

        # *** Lógica de Preprocesamiento y Predicción del Modelo ***
        if MODEL:
            try:
                # Cargar y pre-procesar la imagen usando PIL
                img = Image.open(uploaded_file)
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                img = img.resize((IMG_WIDTH, IMG_HEIGHT))
                img_array = np.array(img) / 255.0
                img_array = np.expand_dims(img_array, axis=0) 

                pred_probs = MODEL.predict(img_array)
                predicted_class_index = np.argmax(pred_probs[0])
                confidence = np.max(pred_probs[0])

                if predicted_class_index < len(BIRD_CLASSES_MODEL):
                   
                    predicted_class_from_model = BIRD_CLASSES_MODEL[predicted_class_index]
                    print(f"DEBUG: Predicción del modelo (clave): '{predicted_class_from_model}' con confianza {confidence:.2f}")

                
                    # Mapeo de nombre de clase del modelo a nombre común en la DB
                    nombre_comun_para_db = predicted_class_from_model
                    
                    if predicted_class_from_model == "Carpinterito_Candela":
                        nombre_comun_para_db = "Carpintero Candela" # Mapeo explícito
                    elif predicted_class_from_model == "Aguila_Pechinegra":
                        nombre_comun_para_db = "Águila Pechinegra"
                    elif predicted_class_from_model == "Clarinero_Escarlata":
                        nombre_comun_para_db = "Clarinero Escarlata"
                    elif predicted_class_from_model == "Condor_Andino":
                        nombre_comun_para_db = "Cóndor Andino"
                    elif predicted_class_from_model == "Pava_Andina":
                        nombre_comun_para_db = "Pava Andina"
                    

                    print(f"DEBUG: Nombre común para buscar en la DB: '{nombre_comun_para_db}'")

                    try:
                        # Busca el ave en la base de datos usando el nombre común esperado en la DB
                        # Utilizamos __iexact para ignorar mayúsculas/minúsculas en la búsqueda
                        predicted_ave_info = Ave.objects.get(nombre_comun__iexact=nombre_comun_para_db)
                        print(f"DEBUG: ¡Ave encontrada en DB!: {predicted_ave_info.nombre_comun}")
                    except Ave.DoesNotExist:
                        classification_error = f"No se encontró información detallada en la DB para '{nombre_comun_para_db}'. (Predicción del modelo: '{predicted_class_from_model}')"
                        print(f"ERROR DB: {classification_error}")
                        # Si no se encuentra, predicted_ave_info sigue siendo None
                    except Exception as db_e:
                        classification_error = f"Error inesperado al buscar en la base de datos: {db_e}"
                        print(f"ERROR DB EXCEPTION: {classification_error}")
                        # Si hay otro error en DB, predicted_ave_info sigue siendo None
                else:
                    classification_error = "Clase predicha fuera de rango de BIRD_CLASSES_MODEL."
                    print(f"ERROR: {classification_error}")
            except Exception as e:
                classification_error = f"Error durante el pre-procesamiento o predicción del modelo: {e}"
                print(f"ERROR CLASSIFICATION: {classification_error}")
        else:
            classification_error = "Modelo de clasificación no cargado. Verifica la ruta y las dependencias."
            print(f"ERROR MODEL: {classification_error}")
    # else:
        # Esto se ejecuta cuando se carga la página sin POST (inicialmente) o si no hay archivo subido
        # No es necesario hacer nada aquí explícitamente para el flujo de clasificación.

    context = {
        'uploaded_image_url': uploaded_image_url,
        'predicted_ave': predicted_ave_info, # Pasa el objeto Ave completo si se encontró
        'classification_error': classification_error,
    }
    print(f"DEBUG: Contexto final enviado al template: predicted_ave={predicted_ave_info is not None}, uploaded_image_url={uploaded_image_url is not None}, error={classification_error is not None}")
    return render(request, 'classifier/clasificador.html', context)

# NUEVA VISTA: Para la pestaña ZONA ANDINA
def zona_andina_view(request):
    """
    Vista para la página de información de la Zona Andina.
    """
    context = {}
    return render(request, 'classifier/zona_andina.html', context)