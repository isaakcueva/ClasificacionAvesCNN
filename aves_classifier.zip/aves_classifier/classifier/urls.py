from django.urls import path
from . import views # Importa las vistas de tu misma aplicación

app_name = 'classifier' # Define el namespace de tu app para URLs inversas

urlpatterns = [
    # URL para la página HOME 
    path('', views.home_view, name='home'),

    # URL para la página CLASIFICADOR
    
    path('clasificador/', views.classify_bird_view, name='classify_bird'),

    # URL para la página ZONA ANDINA
    
    path('zona-andina/', views.zona_andina_view, name='zona_andina'),
]