from django.db import models

class Ave(models.Model):
    nombre_comun = models.CharField(max_length=100) 
    nombre_cientifico = models.CharField(max_length=100, unique=True)

    imagen_ave_detalle = models.ImageField(upload_to='aves_detalle/', blank=True, null=True) # Para la imagen principal de la ficha (tuya)
    mapa_distribucion = models.ImageField(upload_to='mapas_distribucion/', blank=True, null=True) # Para la imagen del mapa de distribución (tuya)
    estado_conservacion = models.CharField(max_length=50)
    habitat = models.TextField()

    def __str__(self):
        return self.nombre_comun